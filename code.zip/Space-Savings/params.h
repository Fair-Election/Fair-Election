#ifndef _PARAMS_H
#define _PARAMS_H

#define N 2000000  // the maximal frequency among all the items
#define M 2000000  // the number of distict items
#define MAX_MEM 2000000 // the maximum memory size

#endif //_PARAMS_H
